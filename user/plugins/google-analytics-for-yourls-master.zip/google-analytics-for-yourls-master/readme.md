> Learn about the plugin [on the plugin page](http://www.seodenver.com/add-google-analytics-link-tagging-yourls/)

## Changelog

### 1.1

* Fixes compatibility with YOURLS 1.7+. Thanks [@ifnull](https://github.com/ifnull) and [@sirtet](https://github.com/sirtet)

### 1.0.4

* Use jQuery `.on()` instead of `.live()`

### 1.0.3

* Stricter coding to prevent notices.

### 1.0.2

* Committed some pull requests to improve functionality, also spelling errors.

### 1.0.1

* Stripped 's' query arg when using bookmarklet

### 1.0

* Launched