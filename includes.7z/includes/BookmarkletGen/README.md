# Bookmarklet Gen

Convert readable Javascript code into bookmarklet links

Home: https://github.com/ozh/bookmarkletgen
