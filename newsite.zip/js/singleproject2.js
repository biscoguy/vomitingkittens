 
  
  
  
	$(window).load(function() {
		$("#status").fadeOut();
		$("#preloader").delay(350).fadeOut("slow");
	})  
	
	
	


	
	
	$(document).ready(
	function() {  
		$("html").niceScroll();
		}
	);	
	
	


  $(document).ready(function(){
    // Target your .container, .wrapper, .post, etc.
    $(".media").fitVids();
  });	









	